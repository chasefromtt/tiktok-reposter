import os
import pickle

from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
TOKEN_DIR_NAME = "TikTokRepostDesktopApp"


def _default_token_file() -> str:
    token_dir = os.path.join(os.getenv("LOCALAPPDATA", os.path.expanduser("~")), TOKEN_DIR_NAME)
    os.makedirs(token_dir, exist_ok=True)
    return os.path.join(token_dir, "token.pickle")


def get_authenticated_service(credentials_file: str, token_file: str | None = None):
    if not os.path.exists(credentials_file):
        raise FileNotFoundError(f"Missing YouTube credentials file: {credentials_file}")

    token_file = token_file or _default_token_file()
    credentials = None
    if os.path.exists(token_file):
        with open(token_file, "rb") as token:
            credentials = pickle.load(token)

    if not credentials or not credentials.valid:
        if credentials and credentials.expired and credentials.refresh_token:
            credentials.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(credentials_file, SCOPES)
            credentials = flow.run_local_server(port=0)
        with open(token_file, "wb") as token:
            pickle.dump(credentials, token)

    return build("youtube", "v3", credentials=credentials)
