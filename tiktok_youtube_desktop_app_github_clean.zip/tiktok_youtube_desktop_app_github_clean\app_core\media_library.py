import csv
import re
from pathlib import Path
from typing import Optional


def first_non_empty(*values: Optional[str]) -> str:
    for value in values:
        text = (value or "").strip()
        if text:
            return text
    return ""


def extract_username_from_url(url: str) -> str:
    match = re.search(r"tiktok\.com/@([^/?#]+)", url or "")
    if match:
        return match.group(1).lstrip("@")
    return ""


def extract_video_id_from_text(text: str) -> str:
    match = re.search(r"(\d{10,})", text or "")
    if match:
        return match.group(1)
    return ""


def extract_username_from_filename(file_name: str) -> str:
    match = re.match(r"@?([^_]+)_video_\d+", file_name or "")
    if match:
        return match.group(1).lstrip("@")
    return ""


def _search_roots(download_dir: str | Path) -> list[Path]:
    download_root = Path(download_dir).resolve()
    roots = [download_root]
    if download_root.parent != download_root:
        roots.append(download_root.parent)
    return roots


def resolve_video_path(download_dir: str | Path, row: dict[str, str], video_id: str, username: str) -> Optional[str]:
    candidates: list[Path] = []

    raw_file_path = (row.get("file_path") or "").strip()
    if raw_file_path:
        file_path = Path(raw_file_path)
        candidates.append(file_path)
        if not file_path.is_absolute():
            for search_root in _search_roots(download_dir):
                candidates.append(search_root / file_path)
        for search_root in _search_roots(download_dir):
            candidates.append(search_root / file_path.name)

    if video_id:
        for search_root in _search_roots(download_dir):
            candidates.append(search_root / f"{video_id}.mp4")

    if username and video_id:
        for search_root in _search_roots(download_dir):
            candidates.append(search_root / f"@{username}_video_{video_id}.mp4")
            candidates.append(search_root / f"{username}_video_{video_id}.mp4")

    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        if candidate.exists() and candidate.is_file():
            return str(candidate.resolve())

    return None


def normalize_media_row(download_dir: str | Path, row: dict[str, str]) -> Optional[dict[str, str]]:
    file_path_text = (row.get("file_path") or "").strip()
    url = (row.get("url") or "").strip()
    video_id = first_non_empty(
        row.get("video_id"),
        row.get("tiktok_id"),
        extract_video_id_from_text(url),
        extract_video_id_from_text(file_path_text),
    )
    if not video_id:
        return None

    username = first_non_empty(
        (row.get("author_username") or "").lstrip("@"),
        extract_username_from_url(url),
        extract_username_from_filename(Path(file_path_text).name),
    ) or "tiktok"

    resolved_path = resolve_video_path(download_dir, row, video_id, username)
    if not resolved_path:
        return None

    title = first_non_empty(row.get("video_description"), row.get("title"), Path(resolved_path).stem)
    description = first_non_empty(row.get("description"), f"Credit to @{username} on TikTok.")
    tags = first_non_empty(row.get("tags"), "TikTok,Shorts")

    return {
        "video_id": video_id,
        "author_username": username,
        "url": url,
        "file_path": resolved_path,
        "title": title,
        "description": description,
        "tags": tags,
    }


def load_media_catalog(download_dir: str | Path) -> list[dict[str, str]]:
    download_root = Path(download_dir).resolve()
    metadata_path = download_root / "metadata.csv"
    media_by_id: dict[str, dict[str, str]] = {}

    if metadata_path.exists():
        with metadata_path.open("r", newline="", encoding="utf-8") as file_obj:
            for row in csv.DictReader(file_obj):
                item = normalize_media_row(download_root, row)
                if not item:
                    continue
                media_by_id[item["video_id"]] = item

    for search_root in _search_roots(download_root):
        for video_path in sorted(search_root.glob("*.mp4")):
            file_name = video_path.name
            video_id = extract_video_id_from_text(file_name)
            if not video_id:
                continue

            username = extract_username_from_filename(file_name) or "tiktok"
            existing = media_by_id.get(video_id)
            candidate = {
                "video_id": video_id,
                "author_username": existing["author_username"] if existing else username,
                "url": existing["url"] if existing else "",
                "file_path": str(video_path.resolve()),
                "title": existing["title"] if existing else video_path.stem,
                "description": existing["description"] if existing else f"Credit to @{username} on TikTok.",
                "tags": existing["tags"] if existing else "TikTok,Shorts",
            }
            media_by_id[video_id] = candidate

    media_items = list(media_by_id.values())
    media_items.sort(
        key=lambda item: Path(item["file_path"]).stat().st_mtime if Path(item["file_path"]).exists() else 0,
        reverse=True,
    )
    return media_items
