import csv
import json
import os
from typing import Optional, Set
from googleapiclient.http import MediaFileUpload
from .auth import get_authenticated_service
from .media_library import first_non_empty, load_media_catalog

YOUTUBE_TITLE_MAX = 100

class QuotaExceededError(Exception):
    pass


def _ensure_upload_log(path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.exists(path):
        with open(path, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(["tiktok_video_id", "youtube_video_id", "title"])


def _load_uploaded_ids(path: str) -> Set[str]:
    if not os.path.exists(path):
        return set()
    uploaded = set()
    with open(path, "r", newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            vid = (row.get("tiktok_video_id") or "").strip()
            if vid:
                uploaded.add(vid)
    return uploaded


def _append_upload_log(path: str, tiktok_id: str, youtube_id: str, title: str) -> None:
    _ensure_upload_log(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow([tiktok_id, youtube_id, title])


def _sanitize_title(title: Optional[str], username: str, video_id: str, title_prefix: str = "") -> str:
    raw = (title or "").strip() or f"TikTok by @{username} ({video_id})"
    raw = " ".join(raw.split())
    if title_prefix:
        raw = f"{title_prefix} {raw}".strip()
    return raw[:YOUTUBE_TITLE_MAX]


def _parse_reason_from_http_error(err: Exception) -> Optional[str]:
    content = getattr(err, "content", None)
    if not content:
        return None
    try:
        if isinstance(content, bytes):
            content = content.decode("utf-8", errors="ignore")
        data = json.loads(content)
        errors = data.get("error", {}).get("errors") or data.get("errors") or []
        if errors and isinstance(errors, list):
            return errors[0].get("reason")
    except Exception:
        return None
    return None


def upload_to_youtube(youtube, video_path: str, title: str, description: str, privacy: str, tags: list[str]) -> Optional[str]:
    body = {
        "snippet": {
            "title": title,
            "description": description,
            "tags": tags,
            "categoryId": "22",
        },
        "status": {
            "privacyStatus": privacy,
            "selfDeclaredMadeForKids": False,
        },
    }
    media = MediaFileUpload(video_path, chunksize=-1, resumable=True)
    request = youtube.videos().insert(part="snippet,status", body=body, media_body=media)
    try:
        response = request.execute()
        return response.get("id")
    except Exception as e:
        if _parse_reason_from_http_error(e) == "quotaExceeded":
            raise QuotaExceededError("YouTube Data API quota exceeded") from e
        raise


def process_and_upload_clips(download_dir: str, credentials_file: str, privacy: str = "public", title_prefix: str = "", default_description: str = "Credit to the original TikTok account.", tags_text: str = "TikTok, Shorts", log=print, selected_video_ids: Optional[Set[str]] = None) -> None:
    upload_log_path = os.path.join(download_dir, "youtube_uploads.csv")
    media_items = load_media_catalog(download_dir)
    if not media_items:
        raise FileNotFoundError(f"No TikTok videos or metadata found in: {download_dir}")

    youtube = get_authenticated_service(credentials_file)
    uploaded_ids = _load_uploaded_ids(upload_log_path)
    tags = [t.strip() for t in tags_text.split(",") if t.strip()]

    for item in media_items:
        video_id = item["video_id"]
        if selected_video_ids and video_id not in selected_video_ids:
            continue

        if video_id in uploaded_ids:
            log(f"Already uploaded TikTok {video_id}; skipping.")
            continue

        video_path = item["file_path"]
        if not os.path.isfile(video_path):
            log(f"Video file not found for TikTok {video_id}; skipping.")
            continue

        username = item["author_username"]
        title_source = first_non_empty(item.get("title"), item.get("description"))
        title = _sanitize_title(title_source, username, video_id, title_prefix)

        description_parts = []
        if (default_description or "").strip():
            description_parts.append(default_description.strip())
        else:
            description_parts.append(f"Credit to @{username} on TikTok.")

        row_description = (item.get("description") or "").strip()
        if row_description and row_description not in description_parts:
            description_parts.append(row_description)
        description = "\n\n".join(description_parts)

        log(f"Uploading: {os.path.basename(video_path)}")
        youtube_id = upload_to_youtube(youtube, video_path, title, description, privacy, tags)
        if youtube_id:
            _append_upload_log(upload_log_path, video_id, youtube_id, title)
            uploaded_ids.add(video_id)
            log(f"Uploaded to YouTube: {youtube_id}")
