@echo off
setlocal

echo Checking for Python...

set "PYTHON_EXE="

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_EXE=py -3.10"
)

if "%PYTHON_EXE%"=="" (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set "PYTHON_EXE=python"
    )
)

if "%PYTHON_EXE%"=="" (
    if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" (
        set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    )
)

if "%PYTHON_EXE%"=="" (
    echo Python was not found.
    echo Install Python 3.10+ from python.org.
    echo IMPORTANT: Check "Add python.exe to PATH" during install.
    pause
    exit /b 1
)

echo Using Python: %PYTHON_EXE%

if not exist "requirements.txt" (
    echo requirements.txt was not found.
    echo Make sure this file is inside the same folder as app.py and requirements.txt.
    pause
    exit /b 1
)

echo Creating virtual environment...
%PYTHON_EXE% -m venv .venv

if errorlevel 1 (
    echo Failed to create virtual environment.
    pause
    exit /b 1
)

echo Upgrading pip...
.venv\Scripts\python.exe -m pip install --upgrade pip

echo Installing requirements...
.venv\Scripts\python.exe -m pip install -r requirements.txt

if errorlevel 1 (
    echo Failed to install requirements.
    pause
    exit /b 1
)

echo Setup complete.
pause
