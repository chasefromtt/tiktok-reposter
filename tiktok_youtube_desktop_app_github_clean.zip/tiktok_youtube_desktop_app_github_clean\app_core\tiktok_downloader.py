import asyncio
import csv
import re
from pathlib import Path
from typing import Any, Iterable, Optional

import yt_dlp

METADATA_FIELDS = [
    "video_id",
    "tiktok_id",
    "author_username",
    "url",
    "file_path",
    "title",
    "video_description",
    "description",
    "tags",
]
TIKTOK_TAGS = "TikTok,Shorts,YouTube Shorts"


def _log(message, logger=None):
    if logger:
        try:
            logger(message)
            return
        except Exception:
            pass
    print(message)


def _clean_username(username_or_url: str) -> str:
    username_or_url = username_or_url.strip()
    if username_or_url.startswith("@"):
        return username_or_url[1:]
    match = re.search(r"tiktok\.com/@([^/?#]+)", username_or_url)
    if match:
        return match.group(1)
    return username_or_url


def _extract_username(url: str, fallback: str = "") -> str:
    match = re.search(r"tiktok\.com/@([^/?#]+)", url or "")
    if match:
        return match.group(1).lstrip("@")
    return fallback.lstrip("@")


def _write_metadata(output_path: Path, rows: list[dict[str, str]]) -> Path:
    metadata_file = output_path / "metadata.csv"
    with metadata_file.open("w", newline="", encoding="utf-8") as file_obj:
        writer = csv.DictWriter(file_obj, fieldnames=METADATA_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    return metadata_file


def _iter_entries(info: Optional[dict[str, Any]]) -> Iterable[dict[str, Any]]:
    if not info:
        return []
    entries = info.get("entries")
    if entries is None:
        return [info]
    return [entry for entry in entries if entry]


def _resolve_file_path(output_path: Path, video_id: str, entry: dict[str, Any]) -> Optional[Path]:
    candidates: list[Path] = []

    for key in ("filepath", "_filename"):
        value = entry.get(key)
        if value:
            candidates.append(Path(value))

    for download in entry.get("requested_downloads") or []:
        for key in ("filepath", "_filename"):
            value = (download or {}).get(key)
            if value:
                candidates.append(Path(value))

    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
        local_candidate = output_path / candidate.name
        if local_candidate.exists():
            return local_candidate.resolve()

    for matched_file in sorted(output_path.glob(f"{video_id}.*")):
        if matched_file.is_file():
            return matched_file.resolve()

    return None


def _build_metadata_row(entry: dict[str, Any], output_path: Path, fallback_username: str) -> Optional[dict[str, str]]:
    video_id = str(entry.get("id") or "").strip()
    if not video_id:
        return None

    file_path = _resolve_file_path(output_path, video_id, entry)
    if not file_path:
        return None

    webpage_url = str(entry.get("webpage_url") or entry.get("original_url") or "").strip()
    username = (
        str(entry.get("uploader_id") or entry.get("channel_id") or "").strip().lstrip("@")
        or _extract_username(webpage_url, fallback_username)
    )
    if not webpage_url and username:
        webpage_url = f"https://www.tiktok.com/@{username}/video/{video_id}"

    raw_title = str(entry.get("title") or "").strip() or f"TikTok video {video_id}"

    return {
        "video_id": video_id,
        "tiktok_id": video_id,
        "author_username": username,
        "url": webpage_url,
        "file_path": str(file_path),
        "title": raw_title,
        "video_description": raw_title,
        "description": f"Original TikTok: {webpage_url}" if webpage_url else f"Credit to @{username} on TikTok.",
        "tags": TIKTOK_TAGS,
    }


class _YTDlpLogger:
    def __init__(self, logger=None):
        self.logger = logger

    def debug(self, message: str) -> None:
        if "[download]" in message and "Destination" in message:
            _log(message, self.logger)

    def warning(self, message: str) -> None:
        _log(f"yt-dlp warning: {message}", self.logger)

    def error(self, message: str) -> None:
        _log(f"yt-dlp error: {message}", self.logger)


def _download_tiktok_clips_sync(username_or_url, output_dir="tiktok_downloads", max_videos=10, logger=None, log=None):
    logger = logger or log
    output_path = Path(output_dir).expanduser().resolve()
    output_path.mkdir(parents=True, exist_ok=True)

    username = _clean_username(str(username_or_url))
    profile_url = f"https://www.tiktok.com/@{username}"
    archive_file = output_path / "downloaded_archive.txt"

    _log(f"Finding TikTok videos for @{username}...", logger)

    def _progress_hook(status: dict[str, Any]) -> None:
        if status.get("status") == "finished":
            filename = Path(status.get("filename") or "").name
            if filename:
                _log(f"Saved {filename}", logger)

    ydl_opts = {
        "download_archive": str(archive_file),
        "format": "mp4/best",
        "ignoreerrors": True,
        "logger": _YTDlpLogger(logger),
        "merge_output_format": "mp4",
        "no_warnings": True,
        "outtmpl": str(output_path / "%(id)s.%(ext)s"),
        "playlistend": max_videos,
        "progress_hooks": [_progress_hook],
        "quiet": True,
        "windowsfilenames": True,
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(profile_url, download=True)
    except Exception as exc:
        _log(f"Download error: {exc}", logger)
        return output_path

    rows: list[dict[str, str]] = []
    seen_ids: set[str] = set()
    for entry in _iter_entries(info):
        row = _build_metadata_row(entry, output_path, username)
        if not row:
            continue
        if row["video_id"] in seen_ids:
            continue
        seen_ids.add(row["video_id"])
        rows.append(row)

    metadata_file = output_path / "metadata.csv"
    if rows or not metadata_file.exists():
        metadata_file = _write_metadata(output_path, rows)
        _log(f"Metadata saved to: {metadata_file}", logger)
    else:
        _log(f"No local video files matched the TikTok results; keeping existing metadata at {metadata_file}", logger)

    _log(f"Prepared metadata for {len(rows)} video(s).", logger)
    return output_path


async def download_tiktok_clips(username_or_url, output_dir="tiktok_downloads", max_videos=10, logger=None, log=None):
    return await asyncio.to_thread(
        _download_tiktok_clips_sync,
        username_or_url,
        output_dir,
        max_videos,
        logger,
        log,
    )
