@echo off
setlocal

if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found. Running setup first...
    call setup_windows_fixed.bat
)

if not exist ".venv\Scripts\python.exe" (
    echo Setup failed.
    pause
    exit /b 1
)

.venv\Scripts\python.exe -m PyInstaller --onefile --windowed app.py
pause
