import csv
import os
import time
from pathlib import Path
from typing import Optional, Set

import requests

from .media_library import first_non_empty, load_media_catalog

GRAPH_API_VERSION = "v25.0"
GRAPH_API_BASE_URL = f"https://graph.facebook.com/{GRAPH_API_VERSION}"


class InstagramUploadError(Exception):
    pass


def _ensure_upload_log(path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.exists(path):
        with open(path, "w", newline="", encoding="utf-8") as file_obj:
            csv.writer(file_obj).writerow(["tiktok_video_id", "instagram_media_id", "caption"])


def _load_uploaded_ids(path: str) -> Set[str]:
    if not os.path.exists(path):
        return set()

    uploaded = set()
    with open(path, "r", newline="", encoding="utf-8") as file_obj:
        for row in csv.DictReader(file_obj):
            video_id = (row.get("tiktok_video_id") or "").strip()
            if video_id:
                uploaded.add(video_id)
    return uploaded


def _append_upload_log(path: str, tiktok_id: str, instagram_media_id: str, caption: str) -> None:
    _ensure_upload_log(path)
    with open(path, "a", newline="", encoding="utf-8") as file_obj:
        csv.writer(file_obj).writerow([tiktok_id, instagram_media_id, caption])


def _meta_error_message(response: requests.Response) -> str:
    try:
        data = response.json()
    except Exception:
        return response.text.strip() or f"HTTP {response.status_code}"

    error = data.get("error") or {}
    if error:
        message = error.get("message") or "Meta API error"
        code = error.get("code")
        subcode = error.get("error_subcode")
        if code is not None and subcode is not None:
            return f"{message} (code {code}, subcode {subcode})"
        if code is not None:
            return f"{message} (code {code})"
        return message

    return response.text.strip() or f"HTTP {response.status_code}"


def _raise_for_meta_error(response: requests.Response) -> None:
    if response.ok:
        return
    raise InstagramUploadError(_meta_error_message(response))


def _parse_json(response: requests.Response) -> dict:
    _raise_for_meta_error(response)
    try:
        data = response.json()
    except Exception as exc:
        raise InstagramUploadError("Meta API returned an unreadable response.") from exc
    if data.get("error"):
        raise InstagramUploadError(_meta_error_message(response))
    return data


def _hashtags_from_text(tags_text: str) -> list[str]:
    hashtags = []
    for tag in (tags_text or "").split(","):
        cleaned = "".join(ch for ch in tag.strip().replace(" ", "") if ch.isalnum() or ch == "_")
        if cleaned:
            hashtags.append(f"#{cleaned}")
    return hashtags


def _build_caption(item: dict[str, str], title_prefix: str, default_description: str, tags_text: str) -> str:
    parts = []

    title = first_non_empty(item.get("title"), f"TikTok repost {item['video_id']}")
    title_line = " ".join(part for part in [title_prefix.strip(), title.strip()] if part).strip()
    if title_line:
        parts.append(title_line)

    description = first_non_empty(default_description, item.get("description"))
    if description:
        parts.append(description)

    source_url = (item.get("url") or "").strip()
    if source_url:
        parts.append(f"Original TikTok: {source_url}")

    hashtags = _hashtags_from_text(tags_text or item.get("tags") or "")
    if hashtags:
        parts.append(" ".join(hashtags))

    caption = "\n\n".join(part for part in parts if part).strip()
    return caption[:2200]


def _create_reel_container(ig_user_id: str, access_token: str, caption: str, log=print) -> tuple[str, str]:
    response = requests.post(
        f"{GRAPH_API_BASE_URL}/{ig_user_id}/media",
        data={
            "media_type": "REELS",
            "upload_type": "resumable",
            "share_to_feed": "true",
            "caption": caption,
            "access_token": access_token,
        },
        timeout=60,
    )
    data = _parse_json(response)

    container_id = str(data.get("id") or "").strip()
    upload_url = first_non_empty(data.get("upload_url"), data.get("uri"), data.get("upload_uri"))
    if not container_id or not upload_url:
        raise InstagramUploadError("Meta did not return a reel container ID and upload URL.")

    log(f"Instagram reel container created: {container_id}")
    return container_id, upload_url


def _upload_video_binary(upload_url: str, access_token: str, video_path: str, log=print) -> None:
    file_size = os.path.getsize(video_path)
    headers = {
        "Authorization": f"OAuth {access_token}",
        "offset": "0",
        "file_size": str(file_size),
        "Content-Type": "application/octet-stream",
    }

    with open(video_path, "rb") as video_file:
        response = requests.post(
            upload_url,
            headers=headers,
            data=video_file,
            timeout=(60, 600),
        )
    _raise_for_meta_error(response)
    log(f"Uploaded {Path(video_path).name} to Meta's reel upload endpoint.")


def _poll_container_status(container_id: str, access_token: str, log=print, max_attempts: int = 60, delay_seconds: int = 5) -> None:
    for attempt in range(1, max_attempts + 1):
        response = requests.get(
            f"{GRAPH_API_BASE_URL}/{container_id}",
            params={
                "fields": "status_code,status",
                "access_token": access_token,
            },
            timeout=60,
        )
        data = _parse_json(response)
        status_code = str(data.get("status_code") or "").upper()
        status = str(data.get("status") or "").strip()

        if status_code in {"FINISHED", "PUBLISHED"}:
            return
        if status_code in {"ERROR", "EXPIRED"}:
            raise InstagramUploadError(f"Instagram container {container_id} failed with status {status_code}: {status}")

        log(f"Instagram processing {container_id}: {status_code or 'UNKNOWN'} ({attempt}/{max_attempts})")
        time.sleep(delay_seconds)

    raise InstagramUploadError(f"Instagram container {container_id} was not ready after {max_attempts * delay_seconds} seconds.")


def _publish_container(ig_user_id: str, container_id: str, access_token: str) -> str:
    response = requests.post(
        f"{GRAPH_API_BASE_URL}/{ig_user_id}/media_publish",
        data={
            "creation_id": container_id,
            "access_token": access_token,
        },
        timeout=60,
    )
    data = _parse_json(response)
    media_id = str(data.get("id") or "").strip()
    if not media_id:
        raise InstagramUploadError("Instagram did not return a media ID after publishing.")
    return media_id


def process_and_upload_instagram_reels(
    download_dir: str,
    access_token: str,
    ig_user_id: str,
    title_prefix: str = "",
    default_description: str = "Credit to the original TikTok account.",
    tags_text: str = "TikTok, Shorts",
    log=print,
    selected_video_ids: Optional[Set[str]] = None,
) -> None:
    if not access_token.strip():
        raise ValueError("Instagram access token is required.")
    if not ig_user_id.strip():
        raise ValueError("Instagram professional account ID is required.")

    upload_log_path = os.path.join(download_dir, "instagram_uploads.csv")
    media_items = load_media_catalog(download_dir)
    if not media_items:
        raise FileNotFoundError(f"No TikTok videos or metadata found in: {download_dir}")

    uploaded_ids = _load_uploaded_ids(upload_log_path)
    pending_items = [
        item for item in media_items
        if (not selected_video_ids or item["video_id"] in selected_video_ids)
    ]

    if not pending_items:
        raise FileNotFoundError("None of the selected videos could be found.")

    for item in pending_items:
        video_id = item["video_id"]
        if video_id in uploaded_ids:
            log(f"Already uploaded TikTok {video_id} to Instagram; skipping.")
            continue

        video_path = item["file_path"]
        if not os.path.isfile(video_path):
            log(f"Video file not found for TikTok {video_id}; skipping.")
            continue

        caption = _build_caption(item, title_prefix, default_description, tags_text)
        log(f"Uploading to Instagram: {Path(video_path).name}")
        container_id, upload_url = _create_reel_container(ig_user_id.strip(), access_token.strip(), caption, log)
        _upload_video_binary(upload_url, access_token.strip(), video_path, log)
        _poll_container_status(container_id, access_token.strip(), log)
        instagram_media_id = _publish_container(ig_user_id.strip(), container_id, access_token.strip())
        _append_upload_log(upload_log_path, video_id, instagram_media_id, caption)
        uploaded_ids.add(video_id)
        log(f"Uploaded to Instagram: {instagram_media_id}")
