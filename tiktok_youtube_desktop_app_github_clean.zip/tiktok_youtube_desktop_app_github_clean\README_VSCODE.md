# Visual Studio Code Setup

## 1. Open The Project
Open this clean GitHub-ready folder in Visual Studio Code.

## 2. Install The Python Extension
Install the official Microsoft `Python` extension.

## 3. Create The Virtual Environment
Run:

```bat
setup_windows.bat
```

Or use:

```txt
Terminal > Run Task > Create venv and install requirements
```

## 4. Run The App
Press `F5` or run:

```bat
run_app.bat
```

## 5. Build The Windows App
Run:

```bat
build_windows.bat
```

The `.exe` will be created in:

```txt
dist/
```

## YouTube Credentials
This public copy does not include a real Google OAuth file.

Use your own OAuth Desktop App JSON and either:
- select it with the app's `Browse` button, or
- place it at `resources/client_secrets.json`

A safe template is included at:

```txt
resources/client_secrets.example.json
```
