import asyncio
import json
import os
import queue
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from app_core.instagram_uploader import InstagramUploadError, process_and_upload_instagram_reels
from app_core.media_library import load_media_catalog
from app_core.tiktok_downloader import download_tiktok_clips
from app_core.youtube_uploader import QuotaExceededError, process_and_upload_clips

APP_TITLE = "TikTok Repost Desktop App"
WINDOW_ALPHA = 0.97
HELP_WINDOW_ALPHA = 0.985
ROOT_BG = "#0b0a07"
CARD_BG = "#17140d"
CARD_BG_ALT = "#1d180f"
BORDER_COLOR = "#4d3a12"
TEXT_PRIMARY = "#f3ead0"
TEXT_MUTED = "#cbbf9d"
TEXT_DARK = "#2a1b00"
ACCENT_GOLD = "#d4a93a"
ACCENT_GOLD_HOVER = "#e5be5a"
ACCENT_GOLD_PRESSED = "#b6871e"
INPUT_BG = "#241d11"
INPUT_BG_ACTIVE = "#2d2415"
LIST_BG = "#120f0a"
LOG_BG = "#0f0d08"
SETTINGS_DIR_NAME = "TikTokRepostDesktopApp"
SETTINGS_FILE_NAME = "ui_state.json"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("860x980")
        self.minsize(780, 860)
        self.configure(bg=ROOT_BG)

        try:
            self.wm_attributes("-alpha", WINDOW_ALPHA)
        except tk.TclError:
            pass

        self.log_queue = queue.Queue()
        self.worker = None
        self.refresh_video_list_requested = False
        self.help_window = None
        self.saved_selected_video_ids = set()
        self._suspend_setting_save = True

        self.tiktok_username = tk.StringVar()
        self.video_count = tk.IntVar(value=20)
        self.download_dir = tk.StringVar(value=os.path.abspath("tiktok_downloads"))
        self.credentials_file = tk.StringVar()
        self.instagram_user_id = tk.StringVar()
        self.instagram_access_token = tk.StringVar()
        self.privacy = tk.StringVar(value="public")
        self.title_prefix = tk.StringVar(value="#Shorts")
        self.tags = tk.StringVar(value="TikTok, Shorts")
        self.description = tk.StringVar(value="Credit to the original TikTok account.")
        self.video_items = []

        self._drag_anchor_mouse = None
        self._drag_anchor_window = None
        self._drag_target_position = None
        self._drag_current_position = None
        self._drag_job = None
        self._drag_active = False

        self._load_settings()
        self._configure_styles()
        self._build_ui()
        self.refresh_video_list()
        self._bind_settings_persistence()
        self._suspend_setting_save = False
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(150, self._drain_logs)

    def _configure_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("App.TFrame", background=ROOT_BG)
        style.configure("Card.TFrame", background=CARD_BG, relief="flat")
        style.configure("AltCard.TFrame", background=CARD_BG_ALT, relief="flat")

        style.configure("Card.TLabel", background=CARD_BG, foreground=TEXT_PRIMARY, font=("Segoe UI", 10))
        style.configure("Alt.TLabel", background=CARD_BG_ALT, foreground=TEXT_PRIMARY, font=("Segoe UI", 10))
        style.configure("MutedCard.TLabel", background=CARD_BG, foreground=TEXT_MUTED, font=("Segoe UI", 9))
        style.configure("MutedAlt.TLabel", background=CARD_BG_ALT, foreground=TEXT_MUTED, font=("Segoe UI", 9))
        style.configure("Header.TLabel", background=CARD_BG, foreground=ACCENT_GOLD, font=("Segoe UI Semibold", 20))
        style.configure("Subheader.TLabel", background=CARD_BG, foreground=TEXT_MUTED, font=("Segoe UI", 10))
        style.configure("SectionTitle.TLabel", background=CARD_BG_ALT, foreground=TEXT_PRIMARY, font=("Segoe UI Semibold", 11))
        style.configure("Stat.TLabel", background=CARD_BG_ALT, foreground=TEXT_MUTED, font=("Segoe UI", 9))
        style.configure("HelpBody.TLabel", background=CARD_BG_ALT, foreground=TEXT_PRIMARY, font=("Segoe UI", 10))

        style.configure(
            "Card.TLabelframe",
            background=CARD_BG_ALT,
            foreground=TEXT_PRIMARY,
            borderwidth=1,
            relief="solid",
        )
        style.configure(
            "Card.TLabelframe.Label",
            background=CARD_BG_ALT,
            foreground=ACCENT_GOLD,
            font=("Segoe UI Semibold", 10),
        )

        style.configure(
            "Gold.TButton",
            background=ACCENT_GOLD,
            foreground=TEXT_DARK,
            borderwidth=0,
            focusthickness=0,
            focuscolor=ACCENT_GOLD,
            padding=(14, 10),
            font=("Segoe UI Semibold", 10),
        )
        style.map(
            "Gold.TButton",
            background=[
                ("pressed", ACCENT_GOLD_PRESSED),
                ("active", ACCENT_GOLD_HOVER),
                ("disabled", "#8a7746"),
            ],
            foreground=[("disabled", "#3a2b08")],
        )

        style.configure(
            "SmallGold.TButton",
            background=ACCENT_GOLD,
            foreground=TEXT_DARK,
            borderwidth=0,
            padding=(12, 8),
            font=("Segoe UI Semibold", 9),
        )
        style.map(
            "SmallGold.TButton",
            background=[
                ("pressed", ACCENT_GOLD_PRESSED),
                ("active", ACCENT_GOLD_HOVER),
            ],
        )

        style.configure(
            "HelpGold.TButton",
            background=ACCENT_GOLD,
            foreground=TEXT_DARK,
            borderwidth=0,
            padding=(11, 6),
            font=("Segoe UI Semibold", 11),
        )
        style.map(
            "HelpGold.TButton",
            background=[
                ("pressed", ACCENT_GOLD_PRESSED),
                ("active", ACCENT_GOLD_HOVER),
            ],
        )

        style.configure(
            "XGold.TButton",
            background=ACCENT_GOLD,
            foreground=TEXT_DARK,
            borderwidth=0,
            padding=(10, 6),
            font=("Segoe UI Semibold", 10),
        )
        style.map(
            "XGold.TButton",
            background=[
                ("pressed", ACCENT_GOLD_PRESSED),
                ("active", ACCENT_GOLD_HOVER),
            ],
        )

        style.configure(
            "App.TEntry",
            fieldbackground=INPUT_BG,
            foreground=TEXT_PRIMARY,
            bordercolor=BORDER_COLOR,
            lightcolor=BORDER_COLOR,
            darkcolor=BORDER_COLOR,
            insertcolor=TEXT_PRIMARY,
            padding=8,
        )
        style.configure(
            "App.TCombobox",
            fieldbackground=INPUT_BG,
            background=INPUT_BG,
            foreground=TEXT_PRIMARY,
            arrowcolor=ACCENT_GOLD,
            bordercolor=BORDER_COLOR,
            lightcolor=BORDER_COLOR,
            darkcolor=BORDER_COLOR,
            padding=6,
        )
        style.map(
            "App.TCombobox",
            fieldbackground=[("readonly", INPUT_BG_ACTIVE)],
            background=[("readonly", INPUT_BG_ACTIVE)],
            foreground=[("readonly", TEXT_PRIMARY)],
        )
        style.configure(
            "Vertical.TScrollbar",
            gripcount=0,
            background=ACCENT_GOLD,
            darkcolor=CARD_BG,
            lightcolor=CARD_BG,
            troughcolor=ROOT_BG,
            bordercolor=ROOT_BG,
            arrowcolor=TEXT_DARK,
        )

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        container = ttk.Frame(self, style="App.TFrame", padding=18)
        container.grid(row=0, column=0, sticky="nsew")
        container.columnconfigure(0, weight=1)
        container.rowconfigure(2, weight=1)
        container.rowconfigure(4, weight=1)

        header = ttk.Frame(container, style="Card.TFrame", padding=(20, 18))
        header.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        header.columnconfigure(0, weight=1)
        header.columnconfigure(1, weight=0)

        title_block = ttk.Frame(header, style="Card.TFrame")
        title_block.grid(row=0, column=0, sticky="w")
        title_label = ttk.Label(title_block, text="TikTok Repost Studio", style="Header.TLabel")
        title_label.grid(row=0, column=0, sticky="w")
        subtitle_label = ttk.Label(
            title_block,
            text="Portrait-focused reposting for TikTok downloads, YouTube Shorts, and Instagram Reels.",
            style="Subheader.TLabel",
        )
        subtitle_label.grid(row=1, column=0, sticky="w", pady=(4, 0))

        header_actions = ttk.Frame(header, style="Card.TFrame")
        header_actions.grid(row=0, column=1, sticky="e")
        ttk.Button(header_actions, text="?", style="HelpGold.TButton", command=self._open_help_window).grid(row=0, column=0, sticky="e")
        drag_hint = ttk.Label(
            header_actions,
            text="Drag this header for smooth movement",
            style="MutedCard.TLabel",
        )
        drag_hint.grid(row=1, column=0, sticky="e", pady=(10, 0))

        self._bind_drag_region(header)
        self._bind_drag_region(title_block)
        self._bind_drag_region(title_label)
        self._bind_drag_region(subtitle_label)
        self._bind_drag_region(drag_hint)

        setup_card = ttk.LabelFrame(container, text="Studio Setup", style="Card.TLabelframe", padding=16)
        setup_card.grid(row=1, column=0, sticky="ew", pady=(0, 12))
        setup_card.columnconfigure(1, weight=1)
        setup_card.columnconfigure(3, weight=1)

        self._build_labeled_entry(setup_card, 0, 0, "TikTok username", self.tiktok_username)
        self._build_labeled_entry(setup_card, 0, 2, "Title prefix", self.title_prefix)

        ttk.Label(setup_card, text="Number of videos", style="Alt.TLabel").grid(row=1, column=0, sticky="w", pady=6)
        ttk.Spinbox(
            setup_card,
            from_=1,
            to=500,
            textvariable=self.video_count,
            width=10,
        ).grid(row=1, column=1, sticky="w", pady=6)
        self._build_labeled_entry(setup_card, 1, 2, "Tags, comma separated", self.tags)

        ttk.Label(setup_card, text="Download folder", style="Alt.TLabel").grid(row=2, column=0, sticky="w", pady=6)
        download_row = ttk.Frame(setup_card, style="AltCard.TFrame")
        download_row.grid(row=2, column=1, sticky="ew", pady=6)
        download_row.columnconfigure(0, weight=1)
        ttk.Entry(download_row, textvariable=self.download_dir, style="App.TEntry").grid(row=0, column=0, sticky="ew")
        ttk.Button(download_row, text="Browse", style="SmallGold.TButton", command=self._pick_download_dir).grid(row=0, column=1, padx=(8, 0))
        self._build_labeled_entry(setup_card, 2, 2, "Default description", self.description)

        ttk.Label(setup_card, text="YouTube client secrets JSON", style="Alt.TLabel").grid(row=3, column=0, sticky="w", pady=6)
        youtube_row = ttk.Frame(setup_card, style="AltCard.TFrame")
        youtube_row.grid(row=3, column=1, sticky="ew", pady=6)
        youtube_row.columnconfigure(0, weight=1)
        ttk.Entry(youtube_row, textvariable=self.credentials_file, style="App.TEntry").grid(row=0, column=0, sticky="ew")
        ttk.Button(youtube_row, text="Browse", style="SmallGold.TButton", command=self._pick_credentials).grid(row=0, column=1, padx=(8, 0))
        self._build_labeled_entry(setup_card, 3, 2, "Instagram account ID", self.instagram_user_id)

        ttk.Label(setup_card, text="YouTube privacy", style="Alt.TLabel").grid(row=4, column=0, sticky="w", pady=6)
        ttk.Combobox(
            setup_card,
            textvariable=self.privacy,
            values=["public", "unlisted", "private"],
            state="readonly",
            width=14,
            style="App.TCombobox",
        ).grid(row=4, column=1, sticky="w", pady=6)
        self._build_labeled_entry(setup_card, 4, 2, "Instagram access token", self.instagram_access_token, show="*")

        ttk.Label(
            setup_card,
            text="The window stays semi-transparent but stronger than before, so the gold controls stay easy to see.",
            style="MutedAlt.TLabel",
        ).grid(row=5, column=0, columnspan=4, sticky="w", pady=(10, 0))

        clips_card = ttk.LabelFrame(container, text="Videos To Repost", style="Card.TLabelframe", padding=16)
        clips_card.grid(row=2, column=0, sticky="nsew", pady=(0, 12))
        clips_card.columnconfigure(0, weight=1)
        clips_card.rowconfigure(2, weight=1)

        ttk.Label(
            clips_card,
            text="Pick only the clips you want. Leave everything unselected to upload all discovered videos.",
            style="Alt.TLabel",
        ).grid(row=0, column=0, sticky="w")

        toolbar = ttk.Frame(clips_card, style="AltCard.TFrame")
        toolbar.grid(row=1, column=0, sticky="ew", pady=(10, 10))
        toolbar.columnconfigure(0, weight=1)

        self.video_summary_label = ttk.Label(toolbar, text="No clips found yet.", style="Stat.TLabel")
        self.video_summary_label.grid(row=0, column=0, sticky="w")

        toolbar_buttons = ttk.Frame(toolbar, style="AltCard.TFrame")
        toolbar_buttons.grid(row=0, column=1, sticky="e")
        ttk.Button(toolbar_buttons, text="Refresh List", style="SmallGold.TButton", command=self.refresh_video_list).pack(side="left", padx=4)
        ttk.Button(toolbar_buttons, text="Select All", style="SmallGold.TButton", command=self.select_all_videos).pack(side="left", padx=4)
        ttk.Button(toolbar_buttons, text="Clear Selection", style="SmallGold.TButton", command=self.clear_video_selection).pack(side="left", padx=4)

        list_frame = ttk.Frame(clips_card, style="AltCard.TFrame")
        list_frame.grid(row=2, column=0, sticky="nsew")
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)

        self.video_listbox = tk.Listbox(
            list_frame,
            selectmode="extended",
            exportselection=False,
            height=10,
            bg=LIST_BG,
            fg=TEXT_PRIMARY,
            selectbackground=ACCENT_GOLD,
            selectforeground=TEXT_DARK,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR,
            highlightcolor=ACCENT_GOLD,
            relief="flat",
            bd=0,
            activestyle="none",
            font=("Segoe UI", 10),
        )
        self.video_listbox.grid(row=0, column=0, sticky="nsew")
        list_scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.video_listbox.yview)
        list_scrollbar.grid(row=0, column=1, sticky="ns")
        self.video_listbox.configure(yscrollcommand=list_scrollbar.set)
        self.video_listbox.bind("<<ListboxSelect>>", self._on_video_selection_changed)

        actions_card = ttk.Frame(container, style="Card.TFrame", padding=(16, 14))
        actions_card.grid(row=3, column=0, sticky="ew", pady=(0, 12))
        actions_card.columnconfigure(0, weight=1)

        ttk.Label(actions_card, text="Actions", style="Header.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            actions_card,
            text="Portrait stacking keeps the buttons cleaner and easier to tap one by one.",
            style="Subheader.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(4, 12))

        action_grid = ttk.Frame(actions_card, style="Card.TFrame")
        action_grid.grid(row=2, column=0, sticky="ew")
        action_grid.columnconfigure(0, weight=1)
        action_grid.columnconfigure(1, weight=1)

        ttk.Button(action_grid, text="Download TikToks", style="Gold.TButton", command=self.download_only).grid(row=0, column=0, sticky="ew", padx=(0, 6), pady=5)
        ttk.Button(action_grid, text="Upload to YouTube", style="Gold.TButton", command=self.upload_only).grid(row=0, column=1, sticky="ew", padx=(6, 0), pady=5)
        ttk.Button(action_grid, text="Upload to Instagram", style="Gold.TButton", command=self.upload_to_instagram).grid(row=1, column=0, sticky="ew", padx=(0, 6), pady=5)
        ttk.Button(action_grid, text="TikTok + YouTube", style="Gold.TButton", command=self.download_and_upload).grid(row=1, column=1, sticky="ew", padx=(6, 0), pady=5)
        ttk.Button(action_grid, text="TikTok + YouTube + Instagram", style="Gold.TButton", command=self.download_upload_everywhere).grid(row=2, column=0, columnspan=2, sticky="ew", pady=5)

        log_card = ttk.LabelFrame(container, text="Activity Log", style="Card.TLabelframe", padding=16)
        log_card.grid(row=4, column=0, sticky="nsew")
        log_card.columnconfigure(0, weight=1)
        log_card.rowconfigure(0, weight=1)

        self.log_text = tk.Text(
            log_card,
            height=14,
            wrap="word",
            bg=LOG_BG,
            fg=TEXT_PRIMARY,
            insertbackground=ACCENT_GOLD,
            selectbackground=ACCENT_GOLD,
            selectforeground=TEXT_DARK,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR,
            highlightcolor=ACCENT_GOLD,
            relief="flat",
            bd=0,
            padx=12,
            pady=12,
            font=("Consolas", 10),
        )
        self.log_text.grid(row=0, column=0, sticky="nsew")
        log_scrollbar = ttk.Scrollbar(log_card, orient="vertical", command=self.log_text.yview)
        log_scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=log_scrollbar.set)

    def _build_labeled_entry(self, parent, row, column, label, variable, show=None):
        ttk.Label(parent, text=label, style="Alt.TLabel").grid(row=row, column=column, sticky="w", pady=6)
        entry_kwargs = {
            "textvariable": variable,
            "style": "App.TEntry",
        }
        if show is not None:
            entry_kwargs["show"] = show
        ttk.Entry(parent, **entry_kwargs).grid(row=row, column=column + 1, sticky="ew", pady=6, padx=(8, 0))

    def _settings_path(self):
        if getattr(sys, "frozen", False):
            base_dir = os.path.join(os.getenv("LOCALAPPDATA", os.path.expanduser("~")), SETTINGS_DIR_NAME)
        else:
            base_dir = os.path.join(os.getenv("LOCALAPPDATA", os.path.expanduser("~")), SETTINGS_DIR_NAME)
        os.makedirs(base_dir, exist_ok=True)
        return os.path.join(base_dir, SETTINGS_FILE_NAME)

    def _load_settings(self):
        settings_path = self._settings_path()
        if not os.path.exists(settings_path):
            return

        try:
            with open(settings_path, "r", encoding="utf-8") as file_obj:
                data = json.load(file_obj)
        except Exception:
            return

        self.tiktok_username.set(data.get("tiktok_username", self.tiktok_username.get()))
        try:
            self.video_count.set(int(data.get("video_count", self.video_count.get())))
        except Exception:
            pass
        self.download_dir.set(data.get("download_dir", self.download_dir.get()))
        self.credentials_file.set(data.get("credentials_file", self.credentials_file.get()))
        self.instagram_user_id.set(data.get("instagram_user_id", self.instagram_user_id.get()))
        self.instagram_access_token.set(data.get("instagram_access_token", self.instagram_access_token.get()))
        self.privacy.set(data.get("privacy", self.privacy.get()))
        self.title_prefix.set(data.get("title_prefix", self.title_prefix.get()))
        self.tags.set(data.get("tags", self.tags.get()))
        self.description.set(data.get("description", self.description.get()))

        saved_geometry = data.get("window_geometry")
        if saved_geometry:
            try:
                self.geometry(saved_geometry)
            except tk.TclError:
                pass

        self.saved_selected_video_ids = set(data.get("selected_video_ids", []))

    def _collect_settings(self):
        try:
            selected_video_ids = sorted(self._get_selected_video_ids())
        except Exception:
            selected_video_ids = sorted(self.saved_selected_video_ids)

        return {
            "tiktok_username": self.tiktok_username.get(),
            "video_count": int(self.video_count.get()),
            "download_dir": self.download_dir.get(),
            "credentials_file": self.credentials_file.get(),
            "instagram_user_id": self.instagram_user_id.get(),
            "instagram_access_token": self.instagram_access_token.get(),
            "privacy": self.privacy.get(),
            "title_prefix": self.title_prefix.get(),
            "tags": self.tags.get(),
            "description": self.description.get(),
            "window_geometry": self.geometry(),
            "selected_video_ids": selected_video_ids,
        }

    def _save_settings(self):
        if self._suspend_setting_save:
            return

        settings_path = self._settings_path()
        try:
            with open(settings_path, "w", encoding="utf-8") as file_obj:
                json.dump(self._collect_settings(), file_obj, indent=2)
        except Exception:
            pass

    def _bind_settings_persistence(self):
        tracked_vars = [
            self.tiktok_username,
            self.video_count,
            self.download_dir,
            self.credentials_file,
            self.instagram_user_id,
            self.instagram_access_token,
            self.privacy,
            self.title_prefix,
            self.tags,
            self.description,
        ]
        for variable in tracked_vars:
            variable.trace_add("write", self._on_setting_var_changed)

    def _on_setting_var_changed(self, *_args):
        self._save_settings()

    def _on_video_selection_changed(self, _event=None):
        try:
            self.saved_selected_video_ids = set(self._get_selected_video_ids())
        except Exception:
            return
        self._save_settings()

    def _on_close(self):
        self._save_settings()
        self.destroy()

    def _bind_drag_region(self, widget):
        widget.bind("<ButtonPress-1>", self._start_window_drag, add="+")
        widget.bind("<B1-Motion>", self._update_window_drag, add="+")
        widget.bind("<ButtonRelease-1>", self._stop_window_drag, add="+")

    def _start_window_drag(self, event):
        self._drag_active = True
        self._drag_anchor_mouse = (event.x_root, event.y_root)
        self._drag_anchor_window = (self.winfo_x(), self.winfo_y())
        self._drag_target_position = [float(self.winfo_x()), float(self.winfo_y())]
        self._drag_current_position = [float(self.winfo_x()), float(self.winfo_y())]
        if self._drag_job is None:
            self._drag_job = self.after(16, self._animate_window_drag)

    def _update_window_drag(self, event):
        if not self._drag_active or not self._drag_anchor_mouse or not self._drag_anchor_window:
            return

        delta_x = event.x_root - self._drag_anchor_mouse[0]
        delta_y = event.y_root - self._drag_anchor_mouse[1]
        self._drag_target_position = [
            float(self._drag_anchor_window[0] + delta_x),
            float(self._drag_anchor_window[1] + delta_y),
        ]

    def _stop_window_drag(self, _event=None):
        self._drag_active = False

    def _animate_window_drag(self):
        if self._drag_target_position is None or self._drag_current_position is None:
            self._drag_job = None
            return

        dx = self._drag_target_position[0] - self._drag_current_position[0]
        dy = self._drag_target_position[1] - self._drag_current_position[1]

        if abs(dx) < 0.5 and abs(dy) < 0.5 and not self._drag_active:
            self._drag_current_position = self._drag_target_position[:]
            self.geometry(f"+{int(round(self._drag_current_position[0]))}+{int(round(self._drag_current_position[1]))}")
            self._drag_job = None
            return

        self._drag_current_position[0] += dx * 0.35
        self._drag_current_position[1] += dy * 0.35
        self.geometry(f"+{int(round(self._drag_current_position[0]))}+{int(round(self._drag_current_position[1]))}")
        self._drag_job = self.after(16, self._animate_window_drag)

    def _open_help_window(self):
        if self.help_window and self.help_window.winfo_exists():
            self.help_window.deiconify()
            self.help_window.lift()
            self.help_window.focus_force()
            return

        self.help_window = tk.Toplevel(self)
        self.help_window.title("How Each System Works")
        self.help_window.geometry("720x760")
        self.help_window.minsize(640, 680)
        self.help_window.configure(bg=ROOT_BG)
        self.help_window.transient(self)
        self.help_window.protocol("WM_DELETE_WINDOW", self._close_help_window)

        try:
            self.help_window.wm_attributes("-alpha", HELP_WINDOW_ALPHA)
        except tk.TclError:
            pass

        help_container = ttk.Frame(self.help_window, style="App.TFrame", padding=18)
        help_container.grid(row=0, column=0, sticky="nsew")
        self.help_window.grid_columnconfigure(0, weight=1)
        self.help_window.grid_rowconfigure(0, weight=1)
        help_container.columnconfigure(0, weight=1)

        header = ttk.Frame(help_container, style="Card.TFrame", padding=(18, 16))
        header.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        header.columnconfigure(0, weight=1)

        ttk.Label(header, text="How To Make Each System Work", style="Header.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            header,
            text="Use this guide any time from the gold ? button in the app header. Scroll through it in order.",
            style="Subheader.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Button(header, text="X", style="XGold.TButton", command=self._close_help_window).grid(row=0, column=1, rowspan=2, sticky="ne")

        body = ttk.Frame(help_container, style="App.TFrame")
        body.grid(row=1, column=0, sticky="nsew")
        body.columnconfigure(0, weight=1)
        body.rowconfigure(0, weight=1)
        help_container.rowconfigure(1, weight=1)

        canvas = tk.Canvas(
            body,
            background=ROOT_BG,
            highlightthickness=0,
            bd=0,
            relief="flat",
        )
        canvas.grid(row=0, column=0, sticky="nsew")

        scrollbar = ttk.Scrollbar(body, orient="vertical", command=canvas.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        canvas.configure(yscrollcommand=scrollbar.set)

        scroll_content = ttk.Frame(canvas, style="App.TFrame")
        scroll_content.columnconfigure(0, weight=1)
        scroll_window = canvas.create_window((0, 0), window=scroll_content, anchor="nw")

        def _refresh_help_scrollregion(_event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def _resize_help_content(event):
            canvas.itemconfigure(scroll_window, width=event.width)

        def _scroll_help_content(event):
            if event.delta:
                canvas.yview_scroll(int(-event.delta / 120), "units")
            return "break"

        scroll_content.bind("<Configure>", _refresh_help_scrollregion)
        canvas.bind("<Configure>", _resize_help_content)
        self.help_window.bind("<MouseWheel>", _scroll_help_content)
        self.help_window.bind("<Escape>", lambda _event: self._close_help_window())

        help_sections = [
            (
                "How To Use This Guide",
                "\n\n".join(
                    [
                        "Read this from top to bottom the first time. The window is intentionally staying the same size, so if the guide feels longer than the box, that is normal: just scroll and keep following the order.",
                        "Everything you type into the main desktop app now saves inside the UI automatically. That means your TikTok username, download folder, YouTube JSON path, Instagram account ID, Instagram token, title prefix, tags, description, and last selected clips stay there when you close and reopen the app.",
                        "If something stops matching what you see on screen, use the section titles as a checklist. TikTok covers downloading, YouTube covers upload setup, and Instagram covers the full Meta app flow we just completed together.",
                    ]
                ),
            ),
            (
                "TikTok Download Flow",
                "\n\n".join(
                    [
                        "Step 1: In the main app, type the TikTok username in the TikTok username box. Use the username itself, not the full profile URL. If the creator name has an @ on TikTok, typing the username without the rest of the link is the cleanest option.",
                        "Step 2: Set Number of videos to however many clips you want the downloader to pull. Then choose the Download folder. That folder is where the app writes the downloaded MP4 files and the metadata.csv file.",
                        "Step 3: Click Download TikToks or one of the combined TikTok workflow buttons. The downloader now uses yt-dlp in the same sync and async pattern that this app expects, so the Activity Log should start filling with progress instead of freezing.",
                        "What it should look like: finished videos appear in the Videos To Repost list, MP4 files show up in your chosen folder, and metadata.csv is regenerated for the downloaded clips. If you later leave the video list with nothing selected, the app treats that as upload all discovered videos. If you highlight specific rows, only those selected rows are uploaded.",
                    ]
                ),
            ),
            (
                "YouTube Setup And Upload",
                "\n\n".join(
                    [
                        "Step 1: In Google Cloud, create or open a project, enable YouTube Data API v3, and create an OAuth client of type Desktop app. Download the client secrets JSON file. In this app, browse to that JSON with the YouTube client secrets JSON picker.",
                        "Step 2: Set YouTube privacy, Title prefix, Tags, and Default description in the main window. Those values are reused when you upload Shorts so you do not have to keep typing them.",
                        "Step 3: Select the clips you want in Videos To Repost, then click Upload to YouTube or one of the combined buttons. The first time, Google may open a browser sign-in and permission page. Approve it with the YouTube account you want to post from.",
                        "What it should look like: the Activity Log reports each upload, the chosen privacy setting is applied to the video, and the uploaded clips appear on YouTube Shorts under the account you authenticated.",
                    ]
                ),
            ),
            (
                "Instagram Part 1: Create The Meta App",
                "\n\n".join(
                    [
                        "Step 1: Go to Meta for Developers, open My Apps, and create a new app. In the current Meta flow, choosing Create an app without a use case is the cleanest starting point when you want a blank app first and then add only the Instagram pieces you need.",
                        "Step 2: When Meta asks about a business portfolio and you do not have one ready, choose I don't want to connect a business portfolio yet. That matches the screen where Meta said no businesses were available and still lets the app be created.",
                        "Step 3: Finish creating the app and land on the dashboard. At this stage the app can look mostly empty. That is expected.",
                        "What it should look like: a fresh app dashboard with an Add use cases button and no finished Instagram setup yet.",
                    ]
                ),
            ),
            (
                "Instagram Part 2: Add The Correct Use Case",
                "\n\n".join(
                    [
                        "Step 1: On the app dashboard, click Add use cases. Scroll until you find Manage messaging & content on Instagram. That is the Instagram row we selected, not Ads, Threads, WhatsApp, or a Facebook-only product.",
                        "Step 2: Select Manage messaging & content on Instagram and save. After saving, the dashboard should change and show an App customization and requirements area.",
                        "Step 3: Click the item that says Customize the Manage messaging & content on Instagram use case. Inside that screen, keep Instagram API selected in the left column and open API setup with Instagram login.",
                        "Step 4: If Meta asks which profile type best describes you, choose Creator for a public-facing creator or influencer style account, or Business for a brand, store, or company account. Either option is fine as long as the Instagram account is professional. A personal-only Instagram account is not enough for this workflow.",
                        "What it should look like: the left sidebar shows Instagram API options such as API setup with Instagram login, API integration helper, and API setup with Facebook login, with the Instagram setup page open in the main panel.",
                    ]
                ),
            ),
            (
                "Instagram Part 3: Fix Insufficient Developer Role",
                "\n\n".join(
                    [
                        "Step 1: Open App roles in the left sidebar of the Meta app and add the exact Instagram account you want to connect as an Instagram Tester.",
                        "Step 2: Right after adding it, the role can show Pending. Pending does not mean ready. The invite still has to be accepted from the Instagram side.",
                        "Step 3: Log into the invited Instagram account, open Apps and Websites, and accept the tester invitation there. Meta's role docs point invited testers to the Apps and Websites area, and this is the step that usually fixes the Insufficient Developer Role message.",
                        "Step 4: Return to App roles and confirm the Pending badge is gone or the tester now looks accepted instead of waiting.",
                        "If you still see Insufficient Developer Role when you click Add account, the usual reasons are: the tester invite is still pending, the browser is signed into the wrong Instagram or Facebook account during the auth flow, or the earlier failed session is cached. Signing out, making sure the tester account is the one currently active, and retrying usually clears it.",
                    ]
                ),
            ),
            (
                "Instagram Part 4: Permissions And Token Generation",
                "\n\n".join(
                    [
                        "Step 1: On API setup with Instagram login, use the Step 1 permissions area to add the required Instagram permissions shown by Meta.",
                        "Step 2: For this desktop uploader, also make sure publishing access is enabled. Current Meta Instagram publishing docs list instagram_business_basic and instagram_business_content_publish as the key permissions for content publishing. Depending on the page you are on, you may also see instagram_business_manage_comments and instagram_business_manage_messages. Those can stay enabled, but the content publishing permission is the important one for posting reels.",
                        "Step 3: Go back to API setup with Instagram login and open Step 2 Generate access tokens. Click Add account and authorize using the same professional Instagram account that already accepted the Instagram Tester invite.",
                        "Step 4: Once Meta finishes, copy the generated access token and keep it safe. The token is usually a long value beginning with IGAA, and the account check response commonly includes values named user_id, username, and id.",
                        "What it should look like: the permissions step is no longer the blocker, Add account goes through without the developer-role error, and you end up with a working token tied to the professional Instagram account you plan to publish from.",
                    ]
                ),
            ),
            (
                "Instagram Part 5: Which Values Go Into This Desktop App",
                "\n\n".join(
                    [
                        "Step 1: Paste the professional Instagram account ID into the Instagram account ID field in the main app. When the API response gives you both user_id and id, use the user_id value for this field.",
                        "Step 2: Paste the generated Instagram access token into the Instagram access token field. The app saves it locally inside the UI now, so you do not have to keep pasting it every launch unless you intentionally replace it.",
                        "Step 3: Ignore the separate id value when the response includes both user_id and id. In the flow we just followed, the user_id-based account identifier is the one that belongs in the app's Instagram account ID box.",
                        "Step 4: Select one or more clips in Videos To Repost and click Upload to Instagram or the all-in-one TikTok + YouTube + Instagram button.",
                        "What it should look like: the Activity Log shows Instagram processing and publish progress, and the selected reel uploads under the connected professional Instagram account.",
                    ]
                ),
            ),
            (
                "What You Can Ignore For Local Testing",
                "\n\n".join(
                    [
                        "For your current tester-based desktop workflow, you do not need to finish every item on the Meta setup page before trying local uploads. The webhook Callback URL and Verify token boxes can stay empty for now, and the Set up Instagram business login and Complete app review steps can wait while you are only testing with your own app and tester account.",
                        "Those areas become important later if you want a broader public product, webhooks, live external users, or advanced review-approved access. For now, the immediate goal is a working tester account, the right permissions, the generated token, and the correct Instagram account ID pasted into this desktop app.",
                    ]
                ),
            ),
            (
                "Common Mistakes And What They Mean",
                "\n\n".join(
                    [
                        "If Add account fails with Insufficient Developer Role, check tester acceptance first. A Pending tester row usually means the invite was created but not accepted yet.",
                        "If Instagram upload fails even with a token, make sure the account is a professional Creator or Business account and not a personal-only profile.",
                        "If Meta shows both user_id and id, do not guess. Put user_id into the Instagram account ID field here, and keep the token in the Instagram access token field.",
                        "If the wrong video uploads, check the selection list. No selection means upload every discovered video. A highlighted selection means upload only the highlighted rows.",
                        "If an upload is skipped, it should now happen only when the app truly cannot find the file on disk. Refresh the list or redownload the clip if a file was moved or deleted outside the app.",
                    ]
                ),
            ),
        ]

        for index, (title, body_text) in enumerate(help_sections):
            self._build_help_section(scroll_content, index, title, body_text)

        footer = ttk.Frame(help_container, style="Card.TFrame", padding=(18, 14))
        footer.grid(row=2, column=0, sticky="ew", pady=(12, 0))
        ttk.Label(
            footer,
            text="Use the mouse wheel to scroll, then close this guide with X when you are done following the steps.",
            style="MutedCard.TLabel",
        ).grid(row=0, column=0, sticky="w")

        canvas.yview_moveto(0)
        self.help_window.grab_set()
        self.help_window.focus_force()

    def _build_help_section(self, parent, row, title, body_text):
        section = ttk.LabelFrame(parent, text=title, style="Card.TLabelframe", padding=16)
        section.grid(row=row, column=0, sticky="ew", pady=(0, 12))
        section.columnconfigure(0, weight=1)
        ttk.Label(
            section,
            text=body_text,
            style="HelpBody.TLabel",
            justify="left",
            wraplength=620,
        ).grid(row=0, column=0, sticky="w")

    def _close_help_window(self):
        if self.help_window and self.help_window.winfo_exists():
            self.help_window.grab_release()
            self.help_window.destroy()
        self.help_window = None

    def _pick_download_dir(self):
        selected = filedialog.askdirectory()
        if selected:
            self.download_dir.set(selected)
            self.refresh_video_list()

    def _pick_credentials(self):
        selected = filedialog.askopenfilename(filetypes=[("JSON files", "*.json"), ("All files", "*.*")])
        if selected:
            self.credentials_file.set(selected)

    def refresh_video_list(self):
        selected_ids = set(self.saved_selected_video_ids)
        try:
            live_selected_ids = self._get_selected_video_ids()
            if live_selected_ids:
                selected_ids = set(live_selected_ids)
        except Exception:
            pass

        self.video_items = load_media_catalog(self.download_dir.get())
        self.video_listbox.delete(0, "end")

        if not self.video_items:
            self.video_summary_label.configure(text="No clips found yet. Download first or point the app at a folder with videos.")
            return

        for item in self.video_items:
            file_name = os.path.basename(item["file_path"])
            display = f"{item['video_id']}  |  {file_name}  |  {item['title']}"
            self.video_listbox.insert("end", display)

        if selected_ids:
            for index, item in enumerate(self.video_items):
                if item["video_id"] in selected_ids:
                    self.video_listbox.selection_set(index)

        self.saved_selected_video_ids = set(self._get_selected_video_ids())

        self.video_summary_label.configure(text=f"{len(self.video_items)} clip(s) ready to repost.")

    def select_all_videos(self):
        self.video_listbox.selection_set(0, "end")
        self._on_video_selection_changed()

    def clear_video_selection(self):
        self.video_listbox.selection_clear(0, "end")
        self._on_video_selection_changed()

    def log(self, message):
        self.log_queue.put(str(message))

    def _drain_logs(self):
        while True:
            try:
                message = self.log_queue.get_nowait()
            except queue.Empty:
                break
            self.log_text.insert("end", message + "\n")
            self.log_text.see("end")

        if self.refresh_video_list_requested:
            self.refresh_video_list_requested = False
            self.refresh_video_list()

        self.after(150, self._drain_logs)

    def _get_selected_video_ids(self):
        selected = set()
        for index in self.video_listbox.curselection():
            if index < len(self.video_items):
                selected.add(self.video_items[index]["video_id"])
        return selected

    def _validate(self, need_username=False, need_credentials=False, need_instagram=False):
        if need_username and not self.tiktok_username.get().strip():
            messagebox.showerror(APP_TITLE, "Enter a TikTok username first.")
            return False
        if need_credentials and not os.path.exists(self.credentials_file.get()):
            messagebox.showerror(APP_TITLE, "Select your YouTube OAuth client JSON file first.")
            return False
        if need_instagram:
            if not self.instagram_user_id.get().strip():
                messagebox.showerror(APP_TITLE, "Enter your Instagram professional account ID first.")
                return False
            if not self.instagram_access_token.get().strip():
                messagebox.showerror(APP_TITLE, "Enter your Instagram access token first.")
                return False
        return True

    def _run_worker(self, target):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(APP_TITLE, "A task is already running.")
            return
        self.worker = threading.Thread(target=target, daemon=True)
        self.worker.start()

    def download_only(self):
        if not self._validate(need_username=True):
            return
        self._run_worker(self._download_task)

    def upload_only(self):
        if not self._validate(need_credentials=True):
            return
        selected_video_ids = self._get_selected_video_ids()
        self._run_worker(lambda: self._upload_task(selected_video_ids))

    def upload_to_instagram(self):
        if not self._validate(need_instagram=True):
            return
        selected_video_ids = self._get_selected_video_ids()
        self._run_worker(lambda: self._instagram_upload_task(selected_video_ids))

    def download_and_upload(self):
        if not self._validate(need_username=True, need_credentials=True):
            return
        selected_video_ids = self._get_selected_video_ids()
        self._run_worker(lambda: self._download_upload_task(selected_video_ids))

    def download_upload_everywhere(self):
        if not self._validate(need_username=True, need_credentials=True, need_instagram=True):
            return
        selected_video_ids = self._get_selected_video_ids()
        self._run_worker(lambda: self._download_upload_everywhere_task(selected_video_ids))

    def _download_task(self):
        try:
            asyncio.run(
                download_tiktok_clips(
                    self.tiktok_username.get(),
                    self.download_dir.get(),
                    int(self.video_count.get()),
                    log=self.log,
                )
            )
            self.refresh_video_list_requested = True
            self.log("Download complete.")
        except Exception as exc:
            self.log(f"Download error: {exc}")

    def _upload_task(self, selected_video_ids=None):
        try:
            process_and_upload_clips(
                download_dir=self.download_dir.get(),
                credentials_file=self.credentials_file.get(),
                privacy=self.privacy.get(),
                title_prefix=self.title_prefix.get(),
                default_description=self.description.get(),
                tags_text=self.tags.get(),
                log=self.log,
                selected_video_ids=selected_video_ids or None,
            )
            self.log("Upload complete.")
        except QuotaExceededError as exc:
            self.log(str(exc))
        except Exception as exc:
            self.log(f"Upload error: {exc}")

    def _instagram_upload_task(self, selected_video_ids=None):
        try:
            process_and_upload_instagram_reels(
                download_dir=self.download_dir.get(),
                access_token=self.instagram_access_token.get(),
                ig_user_id=self.instagram_user_id.get(),
                title_prefix=self.title_prefix.get(),
                default_description=self.description.get(),
                tags_text=self.tags.get(),
                log=self.log,
                selected_video_ids=selected_video_ids or None,
            )
            self.log("Instagram upload complete.")
        except InstagramUploadError as exc:
            self.log(f"Instagram upload error: {exc}")
        except Exception as exc:
            self.log(f"Instagram upload error: {exc}")

    def _download_upload_task(self, selected_video_ids=None):
        self._download_task()
        self._upload_task(selected_video_ids)

    def _download_upload_everywhere_task(self, selected_video_ids=None):
        self._download_task()
        self._upload_task(selected_video_ids)
        self._instagram_upload_task(selected_video_ids)


if __name__ == "__main__":
    App().mainloop()
