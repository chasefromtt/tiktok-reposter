@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found. Running setup first...
    call setup_windows.bat
)
.venv\Scripts\python.exe -m PyInstaller --onefile --windowed --name TikTokToYouTube app.py
pause
