@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=py -3
) else (
    set PYTHON_CMD=python
)

echo Creating virtual environment...
%PYTHON_CMD% -m venv .venv
if errorlevel 1 goto error

echo Upgrading pip...
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto error

echo Installing requirements...
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto error

echo.
echo Setup complete. In VS Code, press F5 or run run_app.bat.
pause
exit /b 0

:error
echo.
echo Setup failed. Make sure Python 3.10 or newer is installed and added to PATH.
pause
exit /b 1
